#!/bin/bash

set -e

./generate_man_pages.sh
./generate_shell_completions.sh
